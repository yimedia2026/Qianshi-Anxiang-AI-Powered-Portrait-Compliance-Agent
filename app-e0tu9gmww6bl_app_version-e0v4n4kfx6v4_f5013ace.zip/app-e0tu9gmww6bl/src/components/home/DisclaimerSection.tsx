import { Disclaimer } from "@/components/common/Disclaimer";

export function DisclaimerSection() {
  return (
    <section id="disclaimer" className="border-t border-border bg-card/50">
      <div className="mx-auto w-full max-w-[1400px] px-4 py-12 md:px-8">
        <div className="mx-auto max-w-3xl">
          <Disclaimer />
        </div>
      </div>
    </section>
  );
}