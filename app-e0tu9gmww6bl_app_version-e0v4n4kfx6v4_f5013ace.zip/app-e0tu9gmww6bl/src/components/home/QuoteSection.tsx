import { Link } from "react-router-dom";
import { motion } from "motion/react";

const INFO = [
  { label: "项目类型", value: "平面 / AI短视频 / AI短剧 / AI广告片 / 广电媒资二次创作" },
  { label: "授权用途", value: "文旅宣传、酱酒品牌营销、跨境出海投放、广电内容制作" },
  { label: "授权时长", value: "6个月 / 12个月 / 更长周期" },
  { label: "投放地域", value: "国内 / 全球（含TikTok、YouTube等海外平台）" },
  { label: "发布渠道", value: "广电播出、短视频平台、社交媒体、线下物料、海外流媒体" },
  { label: "AI人像衍生", value: "是否需要AI生成模特肖像变体" },
];

export function QuoteSection() {
  return (
    <section id="quote" className="border-t border-border">
      <div className="mx-auto w-full max-w-[1400px] px-4 py-20 md:px-8">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <span className="text-xs font-medium text-accent">模块一</span>
            <h2 className="mt-3 text-2xl font-bold text-foreground text-balance md:text-3xl">
              肖像授权报价评估
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground text-pretty">
              通过对话逐步收集项目信息，缺失则主动追问，输出AI预评估报价区间及浮动原因说明，并给出配套合规建议与贵州本地化提示。
            </p>
            <Link
              to="/quote"
              className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-primary transition-colors hover:text-accent"
            >
              立即开始评估
            </Link>
          </div>
          <div className="md:col-span-8">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {INFO.map((item, idx) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: idx * 0.06 }}
                  className="rounded-lg border border-border bg-card p-5"
                >
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  <p className="mt-1 text-sm font-medium text-foreground">{item.value}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}