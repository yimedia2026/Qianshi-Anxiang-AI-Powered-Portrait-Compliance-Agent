import { Link } from "react-router-dom";
import { motion } from "motion/react";

export function HeroSection() {
  return (
    <section id="hero" className="relative overflow-hidden">
      <div className="glow-orb pointer-events-none absolute -right-20 top-0 z-0 h-96 w-96 rounded-full opacity-60" />
      <div className="relative z-10 mx-auto grid w-full max-w-[1400px] grid-cols-1 items-center gap-12 px-4 py-16 md:grid-cols-2 md:px-8 md:py-24">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-4 py-1.5 text-xs text-muted-foreground">{"贵州AI视听产业 · YI Media肖像授权咨询"}</span>
          <h1 className="mt-6 text-4xl font-bold leading-tight text-foreground text-balance md:text-5xl">
            让肖像授权
            <br />
            <span className="text-accent">合规且高效</span>
          </h1>
          <p className="mt-6 max-w-md text-base leading-relaxed text-muted-foreground text-pretty">
            依托5万+各国模特与5万+国内艺人资源，面向AI内容创作完成肖像授权报价预评估与合同风险审查，保障海内外肖像商用合规，尤其满足海外严格的审核要求，助力贵州文旅、酱酒营销、广电内容制作。
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              to="/quote"
              className="rounded-lg bg-primary px-7 py-3 text-center text-sm font-semibold text-primary-foreground transition-transform active:scale-95"
            >
              肖像授权报价评估
            </Link>
            <Link
              to="/review"
              className="rounded-lg border border-border bg-card px-7 py-3 text-center text-sm font-medium text-foreground transition-colors hover:border-primary"
            >
              肖像合同风险审查
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, delay: 0.15 }}
        >
          <div className="rounded-xl border border-border bg-card p-6 shadow-2xl">
            <div className="mb-5 flex items-center justify-between border-b border-border pb-4">
              <span className="text-sm font-semibold text-foreground">工作台</span>
              <span className="text-xs text-accent">AI 智能辅助</span>
            </div>
            <div className="space-y-3">
              <Link
                to="/quote"
                className="flex items-center justify-between rounded-lg border border-border bg-background/60 p-4 transition-colors hover:border-primary"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-foreground">报价评估模块</p>
                  <p className="mt-1 text-xs text-muted-foreground">基准区间 300-1000 美金/项目</p>
                </div>
                <span className="shrink-0 rounded-md bg-primary/15 px-3 py-1 text-xs font-medium text-primary">
                  进入
                </span>
              </Link>
              <Link
                to="/review"
                className="flex items-center justify-between rounded-lg border border-border bg-background/60 p-4 transition-colors hover:border-accent"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-foreground">合同审查模块</p>
                  <p className="mt-1 text-xs text-muted-foreground">8维度专项风险筛查</p>
                </div>
                <span className="shrink-0 rounded-md bg-accent/15 px-3 py-1 text-xs font-medium text-accent">
                  进入
                </span>
              </Link>
            </div>
            <div className="mt-5 grid grid-cols-3 gap-3 text-center">
              <div>
                <p className="text-lg font-bold text-accent">5万+</p>
                <p className="text-xs text-muted-foreground">各国模特</p>
              </div>
              <div>
                <p className="text-lg font-bold text-accent">5万+</p>
                <p className="text-xs text-muted-foreground">国内艺人</p>
              </div>
              <div>
                <p className="text-lg font-bold text-accent">8项</p>
                <p className="text-xs text-muted-foreground">审查维度</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}