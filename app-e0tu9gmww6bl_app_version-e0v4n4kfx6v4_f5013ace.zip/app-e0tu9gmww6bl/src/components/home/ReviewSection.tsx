import { motion } from "motion/react";

type StepTone = "primary" | "accent";
type StepSide = "left" | "right";
interface TimelineStep {
  n: number;
  title: string;
  desc: string;
  side: StepSide;
  tone: StepTone;
}

const STEPS: TimelineStep[] = [
  {
    n: 1,
    title: "粘贴合同文本",
    desc: "上传PDF/TXT或粘贴合同片段",
    side: "left",
    tone: "primary",
  },
  {
    n: 2,
    title: "AI专项条款筛查",
    desc: "聚焦肖像授权专项，不做通用全合同审查",
    side: "right",
    tone: "accent",
  },
  {
    n: 3,
    title: "输出分级报告",
    desc: "高危 / 中风险 / 合规通过",
    side: "left",
    tone: "primary",
  },
];

export function ReviewSection() {
  return (
    <section id="review" className="border-t border-border bg-card/30">
      <div className="mx-auto w-full max-w-[1400px] px-4 py-20 md:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-medium text-accent">模块二</span>
          <h2 className="mt-3 text-2xl font-bold text-foreground text-balance md:text-3xl">
            肖像合同风险审查
          </h2>
          <p className="mt-3 text-sm text-muted-foreground text-pretty">
            粘贴合同文本，聚焦AI肖像授权专项条款进行8维度结构化风险筛查
          </p>
        </div>

        <div className="mx-auto mt-14 max-w-4xl">
          <div className="relative">
            <div className="v-line absolute left-5 top-0 h-full w-px md:left-1/2 md:-translate-x-1/2" />
            <div className="space-y-8">
              {STEPS.map((step) => (
                <motion.div
                  key={step.n}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5 }}
                  className="relative flex flex-col gap-4 md:flex-row md:items-center"
                >
                  {step.side === "left" ? (
                    <>
                      <div className="flex items-center gap-4 md:w-1/2 md:flex-row-reverse md:pr-8 md:text-right">
                        <div
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border text-sm font-bold ${
                            step.tone === "accent"
                              ? "border-accent bg-accent text-accent-foreground"
                              : "border-primary bg-primary text-primary-foreground"
                          }`}
                        >
                          {step.n}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-semibold text-foreground">{step.title}</h4>

                        </div>
                      </div>
                      <div className="hidden md:block md:w-1/2" />
                    </>
                  ) : (
                    <>
                      <div className="hidden md:block md:w-1/2" />
                      <div className="flex items-center gap-4 md:w-1/2 md:pl-8">
                        <div
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border text-sm font-bold ${
                            step.tone === "accent"
                              ? "border-accent bg-accent text-accent-foreground"
                              : "border-primary bg-primary text-primary-foreground"
                          }`}
                        >
                          {step.n}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-semibold text-foreground">{step.title}</h4>
                          <p className="mt-1 text-xs text-muted-foreground">{step.desc}</p>
                        </div>
                      </div>
                    </>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}