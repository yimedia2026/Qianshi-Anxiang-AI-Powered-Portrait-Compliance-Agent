import { ShieldAlert } from "lucide-react";
import { DISCLAIMER_ITEMS } from "@/lib/constants";

interface DisclaimerProps {
  className?: string;
}

export function Disclaimer({ className }: DisclaimerProps) {
  return (
    <div
      className={`rounded-xl border border-border bg-background/60 p-4 md:p-5 ${className ?? ""}`}
    >
      <div className="mb-2 flex items-center gap-2">
        <ShieldAlert className="h-4 w-4 shrink-0 text-warning" />
        <span className="text-sm font-bold text-foreground">重要提示</span>
      </div>
      <ol className="space-y-1.5">
        {DISCLAIMER_ITEMS.map((item, idx) => (
          <li key={idx} className="flex gap-2 text-xs leading-relaxed text-muted-foreground">
            <span className="shrink-0 font-bold text-warning">{idx + 1}.</span>
            <span className="min-w-0">{item}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}