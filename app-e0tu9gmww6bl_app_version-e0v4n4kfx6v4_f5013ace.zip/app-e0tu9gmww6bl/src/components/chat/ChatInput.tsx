import { useRef, useState, type KeyboardEvent } from "react";
import { ArrowUp, Square } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

interface ChatInputProps {
  isStreaming: boolean;
  placeholder?: string;
  onSend: (text: string) => void;
  onStop: () => void;
}

export function ChatInput({ isStreaming, placeholder, onSend, onStop }: ChatInputProps) {
  const [value, setValue] = useState("");
  const ref = useRef<HTMLTextAreaElement>(null);

  const submit = () => {
    const text = value.trim();
    if (!text || isStreaming) return;
    onSend(text);
    setValue("");
    if (ref.current) ref.current.style.height = "auto";
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  const onInput = () => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
  };

  return (
    <div className="rounded-xl border border-border bg-card p-2 focus-within:border-primary">
      <Textarea
        ref={ref}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={onKeyDown}
        onInput={onInput}
        rows={1}
        placeholder={placeholder}
        className="max-h-40 min-h-[40px] resize-none border-0 bg-transparent px-2 py-2 text-sm shadow-none focus-visible:ring-0"
      />
      <div className="flex items-center justify-between px-1 pt-1">
        <span className="text-[10px] text-muted-foreground">Enter 发送 · Shift+Enter 换行</span>
        {isStreaming ? (
          <Button size="icon" variant="secondary" className="h-8 w-8" onClick={onStop}>
            <Square className="h-3.5 w-3.5" />
            <span className="sr-only">停止生成</span>
          </Button>
        ) : (
          <Button
            size="icon"
            className="h-8 w-8"
            onClick={submit}
            disabled={!value.trim()}
          >
            <ArrowUp className="h-4 w-4" />
            <span className="sr-only">发送</span>
          </Button>
        )}
      </div>
    </div>
  );
}