import { useEffect, useRef } from "react";
import { Sparkles } from "lucide-react";
import { ChatMessage } from "./ChatMessage";
import { ChatInput } from "./ChatInput";
import type { ChatMessage as ChatMessageType } from "@/hooks/useChat";

interface ChatPanelProps {
  messages: ChatMessageType[];
  isStreaming: boolean;
  placeholder?: string;
  suggestions?: string[];
  onSend: (text: string) => void;
  onStop: () => void;
}

export function ChatPanel({
  messages,
  isStreaming,
  placeholder,
  suggestions,
  onSend,
  onStop,
}: ChatPanelProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const showSuggestions = suggestions && suggestions.length > 0 && messages.length <= 1;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-3xl space-y-5 px-4 py-6 md:px-6">
          {messages.map((m, idx) => (
            <ChatMessage
              key={m.id}
              message={m}
              isStreaming={isStreaming && idx === messages.length - 1 && m.role === "assistant"}
            />
          ))}
          {showSuggestions && (
            <div className="space-y-2">
              <p className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <Sparkles className="h-3.5 w-3.5 text-accent" />
                试试这样问
              </p>
              <div className="flex flex-col gap-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => onSend(s)}
                    disabled={isStreaming}
                    className="rounded-lg border border-border bg-card px-3 py-2 text-left text-xs text-muted-foreground transition-colors hover:border-primary hover:text-foreground disabled:opacity-50"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </div>
      <div className="border-t border-border bg-background/80 px-4 py-3 backdrop-blur md:px-6">
        <div className="mx-auto w-full max-w-3xl">
          <ChatInput
            isStreaming={isStreaming}
            placeholder={placeholder}
            onSend={onSend}
            onStop={onStop}
          />
        </div>
      </div>
    </div>
  );
}