import { useCallback, useRef, useState } from "react";
import { sendStreamRequest } from "@/lib/sse";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export function useChat(systemPrompt: string, initialMessages: ChatMessage[] = []) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [isStreaming, setIsStreaming] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const streamingRef = useRef("");

  const send = useCallback(
    async (text: string) => {
      const content = text.trim();
      if (!content || isStreaming) return;

      const userMsg: ChatMessage = {
        id: `u-${Date.now()}`,
        role: "user",
        content,
      };
      const assistantId = `a-${Date.now()}`;
      const history = messages.map((m) => ({ role: m.role, content: m.content }));

      setMessages((prev) => [
        ...prev,
        userMsg,
        { id: assistantId, role: "assistant", content: "" },
      ]);
      setIsStreaming(true);
      streamingRef.current = "";
      abortRef.current = new AbortController();

      const allMessages = [
        { role: "system", content: systemPrompt },
        ...history,
        { role: "user", content },
      ];

      const flush = () => {
        const c = streamingRef.current;
        setMessages((prev) =>
          prev.map((m) => (m.id === assistantId ? { ...m, content: c } : m)),
        );
      };

      await sendStreamRequest({
        functionUrl: `${supabaseUrl}/functions/v1/wenxin-text-generation`,
        requestBody: { messages: allMessages },
        supabaseAnonKey,
        signal: abortRef.current.signal,
        onData: (data) => {
          if (data === "[DONE]") return;
          try {
            const parsed = JSON.parse(data);
            const chunk = parsed.choices?.[0]?.delta?.content ?? "";
            if (!chunk) return;
            streamingRef.current += chunk;
            flush();
          } catch {
            /* 跳过无法解析的帧 */
          }
        },
        onComplete: () => {
          flush();
          setIsStreaming(false);
        },
        onError: () => {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantId
                ? { ...m, content: streamingRef.current || "抱歉，回复出现异常，请重试。" }
                : m,
            ),
          );
          setIsStreaming(false);
        },
      });
    },
    [messages, isStreaming, systemPrompt],
  );

  const stop = useCallback(() => {
    abortRef.current?.abort();
    setIsStreaming(false);
  }, []);

  const reset = useCallback(() => {
    setMessages(initialMessages);
  }, [initialMessages]);

  return { messages, isStreaming, send, stop, reset };
}