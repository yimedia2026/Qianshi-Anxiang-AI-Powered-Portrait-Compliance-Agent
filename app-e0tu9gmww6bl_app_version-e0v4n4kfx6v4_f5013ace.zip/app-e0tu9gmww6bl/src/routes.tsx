import Home from './pages/Home';
import QuoteChat from './pages/QuoteChat';
import ContractReview from './pages/ContractReview';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** Accessible without login. Routes without this flag require authentication. Has no effect when RouteGuard is not in use. */
  public?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: '首页',
    path: '/',
    element: <Home />,
    public: true,
  },
  {
    name: '报价评估',
    path: '/quote',
    element: <QuoteChat />,
    public: true,
  },
  {
    name: '合同审查',
    path: '/review',
    element: <ContractReview />,
    public: true,
  },
];
