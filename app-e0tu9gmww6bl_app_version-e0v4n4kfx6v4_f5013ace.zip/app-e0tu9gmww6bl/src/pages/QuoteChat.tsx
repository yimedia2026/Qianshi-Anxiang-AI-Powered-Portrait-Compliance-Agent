import { Link } from "react-router-dom";
import { Calculator, FileSearch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChatPanel } from "@/components/chat/ChatPanel";
import { useChat } from "@/hooks/useChat";
import { QUOTE_SYSTEM_PROMPT, QUOTE_GREETING } from "@/lib/prompts";

const SUGGESTIONS = [
  "AI短视频，文旅宣传，12个月，全球投放，含短视频平台与社交媒体，需要AI人像衍生",
  "平面素材，酱酒品牌营销，6个月，仅国内，线下物料为主",
  "AI广告片，跨境出海投放，12个月，含TikTok/YouTube，需要AI人像衍生",
];

export default function QuoteChat() {
  const { messages, isStreaming, send, stop } = useChat(QUOTE_SYSTEM_PROMPT, [
    { id: "greeting", role: "assistant", content: QUOTE_GREETING },
  ]);

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col">
      <div className="shrink-0 border-b border-border bg-background/80 px-4 py-3 backdrop-blur md:px-8">
        <div className="mx-auto flex w-full max-w-3xl items-center justify-between gap-4">
          <div className="flex min-w-0 items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Calculator className="h-4 w-4" />
            </span>
            <div className="min-w-0">
              <h1 className="truncate text-base font-bold text-foreground">肖像授权报价评估</h1>
              <p className="truncate text-xs text-muted-foreground">模块一 · AI预评估报价区间</p>
            </div>
          </div>
          <Button asChild variant="outline" size="sm" className="shrink-0">
            <Link to="/review">
              <FileSearch className="mr-1.5 h-4 w-4" />
              <span className="hidden sm:inline">切换至</span>合同审查
            </Link>
          </Button>
        </div>
      </div>
      <div className="min-h-0 flex-1">
        <ChatPanel
          messages={messages}
          isStreaming={isStreaming}
          placeholder="描述你的肖像授权项目，例如：AI短视频，文旅宣传，12个月，全球投放…"
          suggestions={SUGGESTIONS}
          onSend={send}
          onStop={stop}
        />
      </div>
    </div>
  );
}