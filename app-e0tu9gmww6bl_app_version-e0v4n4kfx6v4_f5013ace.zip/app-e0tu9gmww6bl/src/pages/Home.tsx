import { HeroSection } from "@/components/home/HeroSection";
import { QuoteSection } from "@/components/home/QuoteSection";
import { ReviewSection } from "@/components/home/ReviewSection";
import { DisclaimerSection } from "@/components/home/DisclaimerSection";

export default function Home() {
  return (
    <div className="w-full">
      <HeroSection />
      <QuoteSection />
      <ReviewSection />
      <DisclaimerSection />
      <footer className="border-t border-border">
        <div className="mx-auto flex w-full max-w-[1400px] flex-col items-center justify-between gap-4 px-4 py-8 md:flex-row md:px-8">
          <p className="text-xs text-muted-foreground">
            © 2026 黔视安像 · 依托 YI Media（广州小翼传媒）业务底座
          </p>
          <p className="text-xs text-muted-foreground">
            面向贵州AI视听产业的肖像合规智能辅助Agent
          </p>
        </div>
      </footer>
    </div>
  );
}