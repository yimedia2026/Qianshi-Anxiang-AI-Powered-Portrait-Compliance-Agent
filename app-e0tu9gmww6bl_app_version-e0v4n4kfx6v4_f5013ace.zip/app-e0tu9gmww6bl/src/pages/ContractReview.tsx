import { Link } from "react-router-dom";
import { FileSearch, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChatPanel } from "@/components/chat/ChatPanel";
import { useChat } from "@/hooks/useChat";
import { REVIEW_SYSTEM_PROMPT, REVIEW_GREETING } from "@/lib/prompts";

const SUGGESTIONS = [
  "请审查以下肖像授权合同：甲方为某酱酒品牌，授权乙方使用模特肖像用于全球TikTok投放，授权期限为永久，允许AI生成模特变体用于大模型训练……",
  "审查这份合同：授权用途包含广电播出与线下物料，未约定素材到期删除义务，肖像同意书与保密协议合并为一份文件签署。",
];

export default function ContractReview() {
  const { messages, isStreaming, send, stop } = useChat(REVIEW_SYSTEM_PROMPT, [
    { id: "greeting", role: "assistant", content: REVIEW_GREETING },
  ]);

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col">
      <div className="shrink-0 border-b border-border bg-background/80 px-4 py-3 backdrop-blur md:px-8">
        <div className="mx-auto flex w-full max-w-3xl items-center justify-between gap-4">
          <div className="flex min-w-0 items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-foreground">
              <FileSearch className="h-4 w-4" />
            </span>
            <div className="min-w-0">
              <h1 className="truncate text-base font-bold text-foreground">肖像合同风险审查</h1>
              <p className="truncate text-xs text-muted-foreground">模块二 · 8维度专项风险筛查</p>
            </div>
          </div>
          <Button asChild variant="outline" size="sm" className="shrink-0">
            <Link to="/quote">
              <Calculator className="mr-1.5 h-4 w-4" />
              <span className="hidden sm:inline">切换至</span>报价评估
            </Link>
          </Button>
        </div>
      </div>
      <div className="min-h-0 flex-1">
        <ChatPanel
          messages={messages}
          isStreaming={isStreaming}
          placeholder="粘贴需要审查的肖像授权合同文本…"
          suggestions={SUGGESTIONS}
          onSend={send}
          onStop={stop}
        />
      </div>
    </div>
  );
}