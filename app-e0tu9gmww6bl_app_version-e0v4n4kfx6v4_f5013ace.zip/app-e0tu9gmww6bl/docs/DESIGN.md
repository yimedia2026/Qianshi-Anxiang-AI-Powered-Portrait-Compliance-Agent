---
name: 分屏叙事
source_draft: 4
fonts:
  heading: "KingsoftCloudFont"
  body: "KingsoftCloudFont"
tokens:
  radius: "0.625rem"
  background: "252 22% 8%"
  foreground: "258 30% 96%"
  card: "252 20% 13%"
  card-foreground: "258 30% 96%"
  primary: "262 48% 52%"
  primary-foreground: "0 0% 100%"
  secondary: "252 24% 20%"
  secondary-foreground: "258 30% 96%"
  muted: "252 16% 18%"
  muted-foreground: "252 12% 70%"
  accent: "174 66% 44%"
  accent-foreground: "252 30% 10%"
  destructive: "350 65% 58%"
  destructive-foreground: "0 0% 100%"
  border: "252 18% 24%"
  input: "252 18% 24%"
  ring: "262 48% 62%"
  popover: "252 22% 11%"
  popover-foreground: "258 30% 96%"
  warning: "38 92% 55%"
  success: "152 60% 45%"
custom_tokens:
  warning-foreground: "252 30% 10%"
  success-foreground: "0 0% 100%"
section_blueprint:
  hero: "relative overflow-hidden"
  quote: "border-t border-border"
  review: "border-t border-border bg-card/30"
  disclaimer: "border-t border-border bg-card/50"
---

## Overview

面向贵州AI视听产业的肖像合规智能辅助应用，采用深紫底色搭配青绿点缀的「深紫权威」气质，营造专业、可信、沉稳的合规工具调性。核心 signature 是分屏叙事结构——左侧品牌主张与功能入口并置，配合竖向发光分割线串联合同审查流程时间轴，让信息收集与风险审查的业务流程在视觉上形成清晰节奏。

## Colors

60% 深紫底面（background/card/muted）奠定沉稳基调，30% 浅紫文字与发丝边框（foreground/muted-foreground/border）承载内容，10% 青绿 accent 与深紫 primary 仅用于 CTA、关键数据、激活态与风险等级标识。warning（琥珀）与 success（翠绿）作为语义风险色，分别用于中风险与合规通过项的圆点徽标，destructive（玫红）用于高危风险。深色策略下深度靠表面明度差（card 13% vs background 8%）而非阴影。

## Typography

标题与正文统一使用「KingsoftCloudFont」（简体中文无衬线），数字与英文回退至 PublicSans，保证中文渲染清晰且具科技企业感。字阶控制在 5 级内：hero 大标题 5xl-6xl、section 标题 3xl、卡片标题 xl、正文 sm/base、元信息 xs。正文行高 1.5-1.6，标题行高 1.1-1.2。字重以 400（正文）与 700（标题/CTA）两档为主。

## Layout

桌面优先，断点仅使用 md。容器居中、最大宽 1400px、内边距 px-4 md:px-8。Hero 采用左右分屏（md:grid-cols-2），左侧叙事文字、右侧功能入口卡片；报价信息采用 12 栏栅格（左 4 栏标题 + 右 8 栏信息网格）；合同审查流程采用竖向发光分割线串联的左右交替时间轴。section 之间以 border-t border-border 分隔，配合 bg-card/30 等微弱底色变化形成层级。

## Components

- button-primary：bg-primary text-primary-foreground，圆角 lg，active:scale-95 触摸反馈
- button-outline：border border-border bg-card text-foreground，hover:border-primary
- card：rounded-xl border border-border bg-card，hover:border-primary/accent 态切换
- entry-card：功能入口行，左信息右「进入」徽标，hover 边框高亮
- timeline-node：圆形编号节点（primary/accent 轮换）+ 竖向发光分割线串联
- risk-badge：圆点 + 文字，destructive/warning/success 三色对应高/中/合规
- disclaimer-box：bg-background/60 边框卡片，编号列表

## Do's and Don'ts

- 禁大面积纯色铺底做核心视觉，hero 仅用低透明度光晕球点缀
- 禁 emoji 作图标，风险等级一律用彩色圆点徽标
- 禁圆角卡片 + 左粗彩色 border accent
- 禁紫→粉→蓝激进渐变
- 每个 section 最多一处 bg-primary CTA，其余用 outline/secondary
- 配色只用语义 token，禁内联 hex/RGB